<?php
    require_once 'conexion.php'; // Conexión a la base de datos
    require_once 'sesion.php';    // Verifica o inicia la sesión

    // Verificamos que la petición sea POST y que existan ambos campos
    if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['admin_username'], $_POST['admin_password'])) {
        // Mensaje al entrar en este primer if
        echo "<script>alert('Primer if: Método POST detectado y campos definidos.');</script>";

        // Limpiar las entradas
        $admin_username = filter_var(trim($_POST['admin_username']), FILTER_SANITIZE_STRING);
        $admin_password = trim($_POST['admin_password']);

        // Verificar que los campos no estén vacíos
        if (!empty($admin_username) && !empty($admin_password)) {
            // Mensaje al entrar en el segundo if (campos no vacíos)
            echo "<script>alert('Segundo if: Los campos no están vacíos.');</script>";

            try {
                // Preparar la consulta con PDO
                $stmt = $pdo->prepare("SELECT * FROM administradores WHERE nombre = :admin_username");
                $stmt->bindParam(':admin_username', $admin_username, PDO::PARAM_STR);
                $stmt->execute();

                // Verificar si se encontró el administrador
                if ($stmt->rowCount() > 0) {
                    // Mensaje al entrar en el tercer if (usuario encontrado)
                    echo "<script>alert('Tercer if: Se encontró al menos un administrador.');</script>";

                    // Obtener el administrador
                    $admin = $stmt->fetch(PDO::FETCH_ASSOC);

                    // Verificar la contraseña (usando password_verify)
                    if (password_verify($admin_password, $admin['contrasena'])) {
                        // Mensaje al entrar en el cuarto if (contraseña correcta)
                        echo "<script>alert('Cuarto if: La contraseña es correcta.');</script>";

                        // Guardar datos del administrador en la sesión
                        $_SESSION['admin_id'] = $admin['id'];
                        $_SESSION['admin_name'] = htmlspecialchars($admin['nombre'], ENT_QUOTES, 'UTF-8');

                        // Redirigir al panel de administración vía JavaScript
                        echo "<script>window.location.href='http://localhost/HACKATHON/administracion/adminPanel.php';</script>";
                        exit; // Detenemos la ejecución
                    } else {
                        // Else de la verificación de contraseña
                        echo "<script>alert('Else del cuarto if: La contraseña es incorrecta.');</script>";
                        echo "<script>window.location.href='login.php';</script>";
                        exit;
                    }
                } else {
                    // Else de rowCount, usuario no encontrado
                    echo "<script>alert('Else del tercer if: Usuario no encontrado.');</script>";
                    echo "<script>window.location.href='login.php';</script>";
                    exit;
                }
            } catch (PDOException $e) {
                // Capturamos la excepción en la consulta
                echo "<script>alert('Excepción: Error en la consulta: " . addslashes($e->getMessage()) . "');</script>";
                echo "<script>window.location.href='login.php';</script>";
                exit;
            }
        } else {
            // Else del segundo if: campos vacíos
            echo "<script>alert('Else del segundo if: Faltan datos de login.');</script>";
            echo "<script>window.location.href='login.php';</script>";
            exit;
        }
    }
?>
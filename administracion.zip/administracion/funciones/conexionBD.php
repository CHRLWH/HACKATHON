<?php
// Configuración de la conexión a la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hackaton";

try {
    // Usar PDO para manejar la base de datos
    $conexion = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    // Configurar atributos de PDO
    $conexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Error en la conexión: " . $e->getMessage());
}
?>

